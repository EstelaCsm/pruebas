package com.pg.facebook.api.listaccounts.node;

import org.knime.core.node.NodeView;

/**
 * <code>NodeView</code> for the "ListAccounts" Node.
 * 
 *
 * @author 
 */
public class ListAccountsNodeView extends NodeView<ListAccountsNodeModel> {

    /**
     * Creates a new view.
     * 
     * @param nodeModel The model (class: {@link ListAccountsNodeModel})
     */
    protected ListAccountsNodeView(final ListAccountsNodeModel nodeModel) {
        super(nodeModel);
        // TODO: generated method stub
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void modelChanged() {
        // TODO: generated method stub
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void onClose() {
        // TODO: generated method stub
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void onOpen() {
        // TODO: generated method stub
    }

}

