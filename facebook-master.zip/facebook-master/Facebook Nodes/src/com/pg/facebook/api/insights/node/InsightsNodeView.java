package com.pg.facebook.api.insights.node;

import org.knime.core.node.NodeView;

/**
 * <code>NodeView</code> for the "Insights" Node.
 * 
 *
 * @author P&G, eBusiness
 */
public class InsightsNodeView extends NodeView<InsightsNodeModel> {

    /**
     * Creates a new view.
     * 
     * @param nodeModel The model (class: {@link InsightsNodeModel})
     */
    protected InsightsNodeView(final InsightsNodeModel nodeModel) {
        super(nodeModel);
        // TODO: generated method stub
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void modelChanged() {
        // TODO: generated method stub
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void onClose() {
        // TODO: generated method stub
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void onOpen() {
        // TODO: generated method stub
    }

}

