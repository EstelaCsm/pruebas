package com.pg.facebook.api.listposts.node;

import org.knime.core.node.NodeView;

/**
 * <code>NodeView</code> for the "ListPosts" Node.
 * 
 *
 * @author P&G, eBusiness
 */
public class ListPostsNodeView extends NodeView<ListPostsNodeModel> {

    /**
     * Creates a new view.
     * 
     * @param nodeModel The model (class: {@link ListPostsNodeModel})
     */
    protected ListPostsNodeView(final ListPostsNodeModel nodeModel) {
        super(nodeModel);
        // TODO: generated method stub
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void modelChanged() {
        // TODO: generated method stub
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void onClose() {
        // TODO: generated method stub
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void onOpen() {
        // TODO: generated method stub
    }

}

